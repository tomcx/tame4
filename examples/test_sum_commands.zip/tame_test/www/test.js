/**
 *  @author T.Schmidt, 03.01.2016
 *  Test sum commands with V4.
 */

var Demo = {
    arrayIn: [],
    arrayOut: [],
    dataIn: {},
    dataOut: {}
};

//Service Client
var Plc;

//Function for starting the client. Defined in "webservice.js"
//in the "resources" directory. 
window.onload = function() {
    Plc =  TAME.WebServiceClient.createClient({
        serviceUrl: 'http://192.168.1.2/TcAdsWebService/TcAdsWebService.dll',
        amsNetId: '192.168.1.2.1.1',
        //alignment: '8',
        onReady: loadExample
    });
}

//This function is called if client is ready (on-ready-function).
function loadExample() {

    //Send button.
    var button1 = document.getElementById("button1");
    
	//Structure definitions
	var structdef = {
        var_1: 'BYTE',
        var_2: 'REAL.2',
        var_3: 'SINT',
        var_4: 'TIME.#h',
        var_5: 'ARRAY.5.STRING.6', //array of 5 strings with 6 characters
        var_6: 'INT1DP'
    };
	 var structdef2 = {
        var_1: 'STRING.5',
        var_2: 'REAL.2',
        var_3: 'SINT',
        var_4: 'INT',
        var_5: 'ARRAY.5.BYTE'
    };
	
	//Init input fields
	for (var i = 0; i < 3; i++) {
            document.getElementById("input1" + i).value = 'ewqr' + i;
            document.getElementById("input2" + i).value = 345.66 + i;
            document.getElementById("input3" + i).value = 45 + i;
            document.getElementById("input4" + i).value = 56 + i;
        for (var j = 0; j < 5; j++) {
           document.getElementById("input5" + i + j).value = 10 + i + j;
        }
    }
        document.getElementById("structinput1").value = 23;
        document.getElementById("structinput2").value = 45.23;
        document.getElementById("structinput3").value = 53;
        document.getElementById("structinput4").value = 3
    for (var i = 0; i < 5; i++) {
        document.getElementById("structinput5" + i).value = 'test' + i;
    }
    document.getElementById("structinput6").value = 22.5;

	
    //Send function
    button1.onclick = function(){
		//Read values for array of structures from HTML
        for (var i = 0; i < 3; i++) {
            Demo.arrayOut[i] = {};
            Demo.arrayOut[i].var_1 = document.getElementById("input1" + i).value;
            Demo.arrayOut[i].var_2 = document.getElementById("input2" + i).value;
            Demo.arrayOut[i].var_3 = document.getElementById("input3" + i).value;
            Demo.arrayOut[i].var_4 = document.getElementById("input4" + i).value;
            Demo.arrayOut[i].var_5 = [];
            for (var j = 0; j < 5; j++) {
                Demo.arrayOut[i].var_5[j] = document.getElementById("input5" + i + j).value;
            }
        }
        //Read values for structure from HTML
        Demo.dataOut.var_1 = document.getElementById("structinput1").value;
        Demo.dataOut.var_2 = document.getElementById("structinput2").value;
        Demo.dataOut.var_3 = document.getElementById("structinput3").value;
        Demo.dataOut.var_4 = document.getElementById("structinput4").value;
        Demo.dataOut.var_5 = [];
        for (var i = 0; i < 5; i++) {
            Demo.dataOut.var_5[i] = document.getElementById("structinput5" + i).value;
        }
        Demo.dataOut.var_6 = document.getElementById("structinput6").value;
		
        //Sum write command
		Plc.sumWriteReq({
			items: [{
					name: '.ArrayOfTestStruct2',
					val: Demo.arrayOut,
					def: structdef2,
				},{
					name: '.TestStruct',
					val: Demo.dataOut,
					def: structdef
				}],
			oc: Demo.readArray
		});
		
    };

    Demo.readArray = function(){
		//Sum read command
        Plc.sumReadReq({
            items: [{
				name: '.ArrayOfTestStruct2',
				jvar: 'Demo.arrayIn',
				def: structdef2,
			},{
				name: '.TestStruct',
				jvar: 'Demo.dataIn',
				def: structdef
			}],
            oc: function() {
				//Write values from array of structures to HTML
                 for (var i = 0; i < 3; i++) {
                    document.getElementById("show1" + i).firstChild.data = Demo.arrayIn[i].var_1;
                    document.getElementById("show2" + i).firstChild.data = Demo.arrayIn[i].var_2;
                    document.getElementById("show3" + i).firstChild.data = Demo.arrayIn[i].var_3;
                    document.getElementById("show4" + i).firstChild.data = Demo.arrayIn[i].var_4;
                    for (var j = 0; j < 5; j++) {
                        document.getElementById("show5" + i + j).firstChild.data = Demo.arrayIn[i].var_5[j];
                    }
                }
				//Write values from structure to HTML
				document.getElementById("showstruct1").firstChild.data = Demo.dataIn.var_1;
                document.getElementById("showstruct2").firstChild.data = Demo.dataIn.var_2;
                document.getElementById("showstruct3").firstChild.data = Demo.dataIn.var_3;
                document.getElementById("showstruct4").firstChild.data = Demo.dataIn.var_4;
                for (var i = 0; i < 5; i++) {
                    document.getElementById("showstruct5" + i).firstChild.data = Demo.dataIn.var_5[i];
                }
                document.getElementById("showstruct6").firstChild.data = Demo.dataIn.var_6;
				
            }
        });
    };
};


